
#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]
using namespace Rcpp;

const double SMOOTH = 0.00000001;
const double ALPHA = 0.8;
const double BETA = 0.6;

// function to solve basic Least square with network cohesion, when covariates are provided.
arma::mat RNC_LS_X(arma::mat X, arma::sp_mat L, arma::mat Y, double lambda, arma::sp_mat W ){

    int n = X.n_rows;
    int p = X.n_cols;
    arma::sp_mat I_sp = arma::speye<arma::sp_mat>(n,n);
    arma::mat I = arma::eye<arma::mat>(n,n);

    //arma::superlu_opts settings;
    //settings.symmetric = true;
    //arma::mat inverse = spsolve(I_sp + lambda * L, I, "superlu", settings);
    // uncomment above if superlu is available. We use the less efficient but by default available lapack.
    arma::mat inverse = spsolve(W + lambda * L, I,"lapack");
    arma::mat b = X.t()*(I-inverse)*Y;
    arma::mat Amat = X.t()*(I-W*inverse)*W*X;
    arma::mat beta = solve(Amat,b);
    arma::mat alpha = inverse*W*(Y-X*beta);
    arma::mat result = arma::join_cols(alpha,beta);

    return result;

}

arma::mat RNC_LS_noX(arma::sp_mat L, arma::mat Y, double lambda, arma::sp_mat W ){

    //arma::superlu_opts settings;
    //settings.symmetric = true;
    //arma::mat inverse = spsolve(I_sp + lambda * L, I, "superlu", settings);
    // uncomment above if superlu is available. We use the less efficient but by default available lapack.
    arma::mat alpha = spsolve(W + lambda * L, W*Y,"lapack");
    return alpha;

}



// The currently available 'as' functions from R sparse matrix to sp_mat all have some numerical issues.
// So we currently only support using the normal matrix as the format for Laplacian. Notice that this
// sacrifices some speed.
// [[Rcpp::export]]
extern "C" SEXP rnc_solver_X(SEXP X, SEXP L, SEXP Y, SEXP lambda, SEXP W){
    arma::mat Xmat=as<arma::mat>(X);
    arma::mat Ldsmat=as<arma::mat>(L);
    arma::sp_mat Lspmat=arma::sp_mat(Ldsmat);
    arma::mat Ymat=as<arma::mat>(Y);
    arma::mat Wdsmat=as<arma::mat>(W);
    arma::sp_mat Wspmat=arma::sp_mat(Wdsmat);
    double lambda_num= as<double>(lambda);

    arma::mat result = RNC_LS_X(Xmat,Lspmat,Ymat,lambda_num,Wspmat);
    return(wrap(result));
}
// [[Rcpp::export]]
extern "C" SEXP rnc_solver_noX(SEXP L, SEXP Y, SEXP lambda, SEXP W){

    arma::mat Ldsmat=as<arma::mat>(L);
    arma::sp_mat Lspmat=arma::sp_mat(Ldsmat);
    arma::mat Ymat=as<arma::mat>(Y);
    arma::mat Wdsmat=as<arma::mat>(W);
    arma::sp_mat Wspmat=arma::sp_mat(Wdsmat);
    double lambda_num= as<double>(lambda);

    arma::mat result = RNC_LS_noX(Lspmat,Ymat,lambda_num,Wspmat);
    return(wrap(result));
}



// function to solve basic Least square with network cohesion, when covariates are provided.
arma::mat RNC_LS_Naive(arma::mat X, arma::sp_mat L, arma::mat Y, double lambda, arma::sp_mat W ){

    int n = X.n_rows;
    int p = X.n_cols;
    arma::sp_mat I_sp = arma::speye<arma::sp_mat>(n,n);
    arma::mat I = arma::eye<arma::mat>(n,n);
    arma::mat X_tilde = arma::join_rows(I,X);
    arma::sp_mat X_tilde_sp = arma::sp_mat(X_tilde);
    arma::sp_mat core = X_tilde_sp.t()*W*X_tilde_sp+lambda*L;

    arma::mat result = spsolve(core,X_tilde.t()*W*Y,"lapack");

    return result;

}

// [[Rcpp::export]]
extern "C" SEXP rnc_solver_naive(SEXP X, SEXP L, SEXP Y, SEXP lambda, SEXP W){
    arma::mat Xmat=as<arma::mat>(X);
    arma::mat Ldsmat=as<arma::mat>(L);
    int n = Xmat.n_rows;
    int p = Xmat.n_cols;
    arma::mat Omega = arma::zeros<arma::mat>(n+p,n+p);
    Omega(arma::span(0,n-1),arma::span(0,n-1)) = Ldsmat;
    arma::sp_mat Lspmat=arma::sp_mat(Omega);
    arma::mat Ymat=as<arma::mat>(Y);
    arma::mat Wdsmat=as<arma::mat>(W);
    arma::sp_mat Wspmat=arma::sp_mat(Wdsmat);
    double lambda_num= as<double>(lambda);

    arma::mat result = RNC_LS_Naive(Xmat,Lspmat,Ymat,lambda_num,Wspmat);
    return(wrap(result));
}


double loglike_bernoulli(arma::mat Y, arma::mat P){
    double result = 0;
    int n = Y.n_rows;
    for (int i = 0; i<n; i++) {
        if (P(i,0) < SMOOTH) {
            P(i,0) = SMOOTH;
        }
        if (P(i,0)>1-SMOOTH) {
            P(i,0) = 1-SMOOTH;
        }
        result += Y(i,0)*log(P(i,0)) + (1-Y(i,0))*log(1-P(i,0));
    }
    return result;
}

arma::mat logit_p(arma::mat eta){
    int n = eta.n_rows;
    arma::mat expeta = exp(eta);
    arma::mat ones = arma::ones(n,1);
    arma::mat result = expeta/(expeta+ones);
    return result;
}


// function to solve logistic regression with network cohesion, when covariates are provided.

arma::mat RNC_Logit_X(arma::mat X, arma::sp_mat L, arma::mat Y, double lambda, arma::mat theta_init, double tol, int max_iter, bool verbose){

    // begin newton method
    int n = X.n_rows;
    int p = X.n_cols;
    int iter = 0;
    double err = 0;
    arma::mat I = arma::eye<arma::mat>(n,n);

    arma::mat X_tilde = arma::join_rows(I,X);
    arma::mat eta, theta_old, theta_new;
    double ell;
    theta_old = theta_init;
    eta = X_tilde * theta_old;
    arma::mat one_n = arma::ones(n,1);
    arma::mat P = logit_p(eta);
    ell = loglike_bernoulli(Y,P);
    arma::mat residual = Y - P;
    arma::mat w_vec = P%(one_n - P);
    arma::mat z = eta + residual/w_vec;
    arma::sp_mat W = arma::sp_mat(n,n);
    W.diag() = w_vec;
    bool converge = false;
    while (!converge) {
        iter += 1;
        theta_new = RNC_LS_Naive(X, L, z, lambda, W );
        err = arma::norm(theta_new - theta_old,"fro")/(arma::norm(theta_old,"fro")+SMOOTH);
        if (err < tol) {
            converge = true;
        }
        theta_old = theta_new;
        eta = X_tilde * theta_old;
        P = logit_p(eta);
        ell = loglike_bernoulli(Y,P);
        residual = Y - P;
        w_vec = P%(one_n - P);
        z = eta + residual/w_vec;
        W.diag() = w_vec;
        if(iter == max_iter){
            if (verbose) {
                Rcout << "Maximum iteraction reached before converge!" << std::endl;
            }

            break;
        }
        if (verbose) {
            Rcout << "Finish iteration " << iter << " with loglikelihood " << ell << std::endl;
        }
        if ((P.max()>1-SMOOTH) || (P.min() < SMOOTH)) {
            converge = true;
        }
    }

    return theta_old;

}


// [[Rcpp::export]]
extern "C" SEXP rnc_logistic_fit(SEXP X, SEXP L, SEXP Y, SEXP lambda, SEXP theta_init, SEXP tol, SEXP max_iter, SEXP verbose){
    arma::mat Xmat=as<arma::mat>(X);
    arma::mat Ldsmat=as<arma::mat>(L);
    int n = Xmat.n_rows;
    int p = Xmat.n_cols;
    arma::mat Omega = arma::zeros<arma::mat>(n+p,n+p);
    Omega(arma::span(0,n-1),arma::span(0,n-1)) = Ldsmat;
    arma::sp_mat Lspmat=arma::sp_mat(Omega);
    //arma::sp_mat Lspmat=arma::sp_mat(Ldsmat);
    arma::mat Ymat=as<arma::mat>(Y);
    double lambda_num= as<double>(lambda);
    double tol_num= as<double>(tol);
    bool verbose_ind= as<bool>(verbose);
    int iter_max_num= as<int>(max_iter);
    arma::mat thetamat=as<arma::mat>(theta_init);
    arma::mat result = RNC_Logit_X(Xmat,Lspmat,Ymat,lambda_num,thetamat,tol_num,iter_max_num,verbose_ind);
    return(wrap(result));
}

// function to solve logistic regression with network cohesion, when covariates are not provided.

arma::mat RNC_Logit_noX(arma::sp_mat L, arma::mat Y, double lambda, arma::mat theta_init, double tol, int max_iter, bool verbose){

    // begin newton method
    int n = Y.n_rows;
    int iter = 0;
    double err = 0;
    arma::mat I = arma::eye<arma::mat>(n,n);

    arma::mat X_tilde = I;
    arma::mat eta, theta_old, theta_new;
    double ell;
    theta_old = theta_init;
    eta = X_tilde * theta_old;
    arma::mat one_n = arma::ones(n,1);
    arma::mat P = logit_p(eta);
    ell = loglike_bernoulli(Y,P);
    arma::mat residual = Y - P;
    arma::mat w_vec = P%(one_n - P);
    arma::mat z = eta + residual/w_vec;
    arma::sp_mat W = arma::sp_mat(n,n);
    W.diag() = w_vec;
    bool converge = false;
    while (!converge) {
        iter += 1;
        theta_new = RNC_LS_noX(L, z, lambda, W );
        err = arma::norm(theta_new - theta_old,"fro")/(arma::norm(theta_old,"fro")+SMOOTH);
        if (err < tol) {
            converge = true;
        }
        theta_old = theta_new;
        eta = X_tilde * theta_old;
        P = logit_p(eta);
        ell = loglike_bernoulli(Y,P);
        residual = Y - P;
        w_vec = P%(one_n - P);
        z = eta + residual/w_vec;
        W.diag() = w_vec;
        if(iter == max_iter){
            if (verbose) {
                Rcout << "Maximum iteraction reached before converge!" << std::endl;
            }

            break;
        }
        if (verbose) {
            Rcout << "Finish iteration " << iter << " with loglikelihood " << ell << std::endl;

        }
        if ((P.max()>1-SMOOTH) || (P.min() < SMOOTH)) {
            converge = true;
        }
    }

    return theta_old;

}


// [[Rcpp::export]]
extern "C" SEXP rnc_logistic_fit_noX(SEXP L, SEXP Y, SEXP lambda, SEXP theta_init, SEXP tol, SEXP max_iter, SEXP verbose){
    arma::mat Ldsmat=as<arma::mat>(L);
    int n = Ldsmat.n_rows;
    arma::mat Omega = Ldsmat;
    arma::sp_mat Lspmat=arma::sp_mat(Omega);
    arma::mat Ymat=as<arma::mat>(Y);
    double lambda_num= as<double>(lambda);
    double tol_num= as<double>(tol);
    bool verbose_ind= as<bool>(verbose);
    int iter_max_num= as<int>(max_iter);
    arma::mat thetamat=as<arma::mat>(theta_init);
    arma::mat result = RNC_Logit_noX(Lspmat,Ymat,lambda_num,thetamat,tol_num,iter_max_num,verbose_ind);
    return(wrap(result));
}


double cox_partialloglike(arma::mat delta, arma::mat eta, arma::mat PairMat){
    int n = eta.n_rows;
    arma::mat expeta = exp(eta);
    double result = 0;
    for (int i=0; i<n; i++) {
        double tmp = 0;
        if (delta(i,0)==1) {
            tmp = eta(i,0);
            double tmpsum = 0;
            arma::mat summat = PairMat.row(i)*expeta;
            tmpsum = summat(0,0);
            tmp = tmp - log(tmpsum);
            result = result + tmp;
        }
    }
    return result;
}

void cox_newton_terms_calculation(arma::mat &grad, arma::mat &hess, arma::mat &response_g, arma::mat delta, arma::mat eta, arma::mat PairMat){

    int n = eta.n_rows;
    arma::mat expeta = exp(eta);
    
    for (int i = 0; i<n; i++) {
        double tmp_grad=delta(i,0);
        double tmp_hess = 0;
        for (int j=0; j<n; j++) {
            if ((int)PairMat(j,i)==1 && (int)delta(j,0)==1) {
                arma::mat denom_mat = PairMat.row(j)*expeta;
                double denom = denom_mat(0,0);
                tmp_grad = tmp_grad - expeta(i,0)/(denom+SMOOTH);
                tmp_hess = tmp_hess + expeta(i,0)*(denom-expeta(i,0))/(denom*denom+SMOOTH);
            }
        }
        grad(i,0) = tmp_grad;
        hess(i,0) = tmp_hess;
        response_g(i,0) = eta(i,0) + grad(i,0)/(hess(i,0)+SMOOTH);
    }
    return;
}



// function to fit Cox's proportional hazard model with network cohesion, when covariates are provided. The Breslow approximation is used for ties. The detailed algorithm formulation can be found in Generalized Additive Models, by Hastie and Tibshirani
// There are many operations to calculate sets, which can be done more efficiently in R. So we will assume such sets as the input.

arma::mat RNC_Cox_X(arma::mat X, arma::sp_mat L, arma::mat Y, arma::mat delta, double lambda, arma::mat theta_init, double tol, int max_iter, bool verbose){

    // begin newton method
    int n = X.n_rows;
    int p = X.n_cols;
    
    // First find the hazard set relationship
    // For each row i, the jth position is 1 if yj >= yi;
    // For each column j, the ith position is 1 if yi <= yj;
    arma::mat PairMat = arma::zeros<arma::mat>(n,n);
    for (int i=0; i<n; i++) {
        double dr = 0;
        for (int j=0; j<n; j++) {
            if (Y(i,0)<=Y(j,0)) {
                PairMat(i,j) = 1;
            }
        }
        
    }
    //Rcout << "Finish pairwise comparison " << std::endl;
    
    arma::mat grad(n,1);
    arma::mat hess=arma::zeros<arma::mat>(n,1);
    arma::mat response_g(n,1);
    
    
    int iter = 0;
    double err = 0;
    arma::mat I = arma::eye<arma::mat>(n,n);

    arma::mat X_tilde = arma::join_rows(I,X);
    arma::mat eta, theta_old, theta_new;
    double ell;
    theta_old = theta_init;
    eta = X_tilde * theta_old;
    arma::mat one_n = arma::ones(n,1);
    // calculate terms needed for newton
    //Rcout << "Begin first newton calculation " << std::endl;
    cox_newton_terms_calculation(grad, hess, response_g, delta, eta, PairMat);
    
    arma::sp_mat H = arma::sp_mat(n,n);
    H.diag() = hess;
    bool converge = false;
    while (!converge) {
        iter += 1;
        theta_new = RNC_LS_Naive(X, L, response_g, lambda, H );
        err = arma::norm(theta_new - theta_old,"fro")/(arma::norm(theta_old,"fro")+SMOOTH);
        if (err < tol) {
            converge = true;
        }
        theta_old = theta_new;
        eta = X_tilde * theta_old;
        ell = cox_partialloglike(delta, eta, PairMat);
        cox_newton_terms_calculation(grad, hess, response_g, delta, eta, PairMat);
        H.diag() = hess;
        if(iter == max_iter){
            if (verbose) {
                Rcout << "Maximum iteraction reached before converge!" << std::endl;
            }

            break;
        }
        if (verbose) {
            Rcout << "Begin iteration " << iter << " with partial loglikelihood " << ell << std::endl;
        }

    }

    return theta_old;

}


// [[Rcpp::export]]
extern "C" SEXP rnc_cox_fit(SEXP X, SEXP L, SEXP Y, SEXP delta, SEXP lambda, SEXP theta_init, SEXP tol, SEXP max_iter, SEXP verbose){
    //Rcout << "Begin converting objects " << std::endl;
    arma::mat Xmat=as<arma::mat>(X);
    //Rcout << "Begin converting L " << std::endl;
    arma::mat Ldsmat=as<arma::mat>(L);
    int n = Xmat.n_rows;
    int p = Xmat.n_cols;
    arma::mat Omega = arma::zeros<arma::mat>(n+p,n+p);
    //Rcout << "Begin incorporating L " << std::endl;
    Omega(arma::span(0,n-1),arma::span(0,n-1)) = Ldsmat;
    arma::sp_mat Lspmat=arma::sp_mat(Omega);
    //arma::sp_mat Lspmat=arma::sp_mat(Ldsmat);
    arma::mat Ymat=as<arma::mat>(Y);
    arma::mat deltamat=as<arma::mat>(delta);
    double lambda_num= as<double>(lambda);
    double tol_num= as<double>(tol);
    bool verbose_ind= as<bool>(verbose);
    int iter_max_num= as<int>(max_iter);
    arma::mat thetamat=as<arma::mat>(theta_init);
    //Rcout << "Begin C calculation " << std::endl;
    arma::mat result = RNC_Cox_X(Xmat,Lspmat,Ymat,deltamat,lambda_num,thetamat,tol_num,iter_max_num,verbose_ind);
    return(wrap(result));
}




arma::mat RNC_Cox_noX(arma::sp_mat L, arma::mat Y, arma::mat delta, double lambda, arma::mat theta_init, double tol, int max_iter, bool verbose){
    
    // begin newton method
    int n = Y.n_rows;
    
    // First find the hazard set relationship
    // For each row i, the jth position is 1 if yj >= yi;
    // For each column j, the ith position is 1 if yi <= yj;
    arma::mat PairMat = arma::zeros<arma::mat>(n,n);
    for (int i=0; i<n; i++) {
        double dr = 0;
        for (int j=0; j<n; j++) {
            if (Y(i,0)<=Y(j,0)) {
                PairMat(i,j) = 1;
            }
        }
        
    }
    //Rcout << "Finish pairwise comparison " << std::endl;
    
    arma::mat grad(n,1);
    arma::mat hess=arma::zeros<arma::mat>(n,1);
    arma::mat response_g(n,1);
    
    
    int iter = 0;
    double err = 0;
    arma::mat eta, theta_old, theta_new;
    double ell;
    theta_old = theta_init;
    eta = theta_old;
    // calculate terms needed for newton
    //Rcout << "Begin first newton calculation " << std::endl;
    cox_newton_terms_calculation(grad, hess, response_g, delta, eta, PairMat);
    
    arma::sp_mat H = arma::sp_mat(n,n);
    H.diag() = hess;
    bool converge = false;
    while (!converge) {
        iter += 1;
        theta_new = RNC_LS_noX(L, response_g, lambda, H );
        err = arma::norm(theta_new - theta_old,"fro")/(arma::norm(theta_old,"fro")+SMOOTH);
        if (err < tol) {
            converge = true;
        }
        theta_old = theta_new;
        eta = theta_old;
        ell = cox_partialloglike(delta, eta, PairMat);
        cox_newton_terms_calculation(grad, hess, response_g, delta, eta, PairMat);
        H.diag() = hess;
        if(iter == max_iter){
            if (verbose) {
                Rcout << "Maximum iteraction reached before converge!" << std::endl;
            }
            
            break;
        }
        if (verbose) {
            Rcout << "Begin iteration " << iter << " with partial loglikelihood " << ell << std::endl;
        }
        
    }
    
    return theta_old;
    
}



// [[Rcpp::export]]
extern "C" SEXP rnc_cox_fit_noX(SEXP L, SEXP Y, SEXP delta, SEXP lambda, SEXP theta_init, SEXP tol, SEXP max_iter, SEXP verbose){
    arma::mat Ldsmat=as<arma::mat>(L);
    int n = Ldsmat.n_rows;
    int p = 0;
    arma::mat Omega = arma::zeros<arma::mat>(n+p,n+p);
    //Rcout << "Begin incorporating L " << std::endl;
    Omega(arma::span(0,n-1),arma::span(0,n-1)) = Ldsmat;
    arma::sp_mat Lspmat=arma::sp_mat(Omega);
    //arma::sp_mat Lspmat=arma::sp_mat(Ldsmat);
    arma::mat Ymat=as<arma::mat>(Y);
    arma::mat deltamat=as<arma::mat>(delta);
    double lambda_num= as<double>(lambda);
    double tol_num= as<double>(tol);
    bool verbose_ind= as<bool>(verbose);
    int iter_max_num= as<int>(max_iter);
    arma::mat thetamat=as<arma::mat>(theta_init);
    //Rcout << "Begin C calculation " << std::endl;
    arma::mat result = RNC_Cox_noX(Lspmat,Ymat,deltamat,lambda_num,thetamat,tol_num,iter_max_num,verbose_ind);
    return(wrap(result));
}




double Cox_Partial(arma::mat eta, arma::mat Y, arma::mat delta){
    
    // begin newton method
    int n = Y.n_rows;
    
    // First find the hazard set relationship
    // For each row i, the jth position is 1 if yj >= yi;
    // For each column j, the ith position is 1 if yi <= yj;
    arma::mat PairMat = arma::zeros<arma::mat>(n,n);
    for (int i=0; i<n; i++) {
        double dr = 0;
        for (int j=0; j<n; j++) {
            if (Y(i,0)<=Y(j,0)) {
                PairMat(i,j) = 1;
            }
        }
        
    }
    double ell;
    ell = cox_partialloglike(delta, eta, PairMat);

    return ell;
    
}




// [[Rcpp::export]]
extern "C" SEXP cox_pll(SEXP eta, SEXP Y, SEXP delta){
    //Rcout << "Begin converting objects " << std::endl;
    arma::mat etamat=as<arma::mat>(eta);
    //arma::sp_mat Lspmat=arma::sp_mat(Ldsmat);
    arma::mat Ymat=as<arma::mat>(Y);
    arma::mat deltamat=as<arma::mat>(delta);
   //arma::mat result = Ldsmat(ind,col_ind);
    double result = Cox_Partial(etamat, Ymat, deltamat);
   return(wrap(result));
}





// Sections for graphical lasso part

// function for soft-thresholding

double soft_thres(double x, double lambda){
    if (std::abs(x) < lambda) {
        return 0;
    }else{
        if (x>0) {
            return x-lambda;
        }else{
            return x+lambda;
        }
    }
}


// function to solve lasso estimating equation.
arma::mat lasso_est(arma::mat V, arma::mat s, double lambda, double tol, int iter_max){
    
    int p = V.n_cols;
    double err = 1.0;
    arma::mat beta = arma::zeros<arma::mat>(p,1);
    arma::mat beta_old = beta;
    for (int iter=0; iter < iter_max; iter++) {
        for (int j=0; j<p; j++) {
            double v_sum = 0;
            for (int k=0; k<p; k++) {
                if (k!=j) {
                    v_sum += V(k,j)*beta(k,0);
                }
            }
            beta(j,0) = soft_thres(s(j,0)-v_sum,lambda)/V(j,j);
        }
        err = arma::norm(beta - beta_old,"fro")/(arma::norm(beta_old,"fro")+SMOOTH);
        //Rcout << "Begin iteration " << iter << " with relative difference " << err << std::endl;
        if (err < tol) {
            break;
        }
        beta_old = beta;
    }

    
    return beta;
    
}




// function of inner iteration of glasso for jth variable
void glasso_inner_j(arma::mat &W, arma::mat &Theta, arma::mat S, int j, double lambda, double tol, int iter_max, bool final){
    
    int p = W.n_cols;
    arma::mat W_11 = arma::zeros<arma::mat>(p-1,p-1);
    //W_11 = W.submat(0,0,p-1,p-1);
    arma::mat s_12 = arma::zeros<arma::mat>(p-1,1);
    
    if (j==0) {
        W_11 = W.submat(1,1,p-1,p-1);
        s_12 = S.submat(1,0,p-1,0);
    }else{
        if (j==p-1) {
            W_11 = W.submat(0,0,p-2,p-2);
            s_12 = S.submat(0,j,p-2,j);
        }else{
            W_11.submat(0,0,j-1,j-1) = W.submat(0,0,j-1,j-1);
            W_11.submat(0,j,j-1,p-2) = W.submat(0,j+1,j-1,p-1);
            W_11.submat(j,0,p-2,j-1) = W.submat(j+1,0,p-1,j-1);
            W_11.submat(j,j,p-2,p-2) = W.submat(j+1,j+1,p-1,p-1);
            s_12.submat(0,0,j-1,0) = S.submat(0,j,j-1,j);
            s_12.submat(j,0,p-2,0) = S.submat(j+1,j,p-1,j);
        }
    }
    
    arma::mat beta = lasso_est(W_11, s_12,lambda,tol,iter_max);
    arma::mat w_12 = W_11*beta;
    //arma::mat w_12 =arma::zeros<arma::mat>(p-1,1);
    //w_12(0,0) = 0.1;
    //w_12(1,0) = 0.2;
    //w_12(2,0) = 0.3;
    
    if (j==0) {
        W.submat(1,0,p-1,0) = w_12;
        W.submat(0,1,0,p-1) = w_12.t();
        if (final==true) {
            arma::mat prod = w_12.t()*beta;
            double theta22 = 1.0/(W(j,j)-prod(0,0));
            Theta.submat(1,0,p-1,0) = beta*(-1*theta22);
            Theta.submat(0,1,0,p-1) = Theta.submat(1,0,p-1,0).t();
            Theta(j,j) = theta22;
        }
    }else{
        if (j==p-1) {
            W.submat(0,j,p-2,j) = w_12;
            W.submat(j,0,j,p-2) = w_12.t();
            if (final==true) {
                arma::mat prod = w_12.t()*beta;
                double theta22 = 1.0/(W(j,j)-prod(0,0));
                Theta.submat(0,j,p-2,j) = beta*(-1*theta22);
                Theta.submat(j,0,j,p-2) = Theta.submat(0,j,p-2,j).t();
                Theta(j,j) = theta22;
            }
        }else{
            W.submat(0,j,j-1,j) = w_12.submat(0,0,j-1,0);
            W.submat(j,0,j,j-1) = w_12.submat(0,0,j-1,0).t();
            W.submat(j+1,j,p-1,j) = w_12.submat(j,0,p-2,0);
            W.submat(j,j+1,j,p-1) = w_12.submat(j,0,p-2,0).t();
            if (final==true) {
                arma::mat prod = w_12.t()*beta;
                double theta22 = 1.0/(W(j,j)-prod(0,0));
                arma::mat coef = beta*(-1*theta22);
                Theta(j,j) = theta22;
                Theta.submat(0,j,j-1,j) = coef.submat(0,0,j-1,0);
                Theta.submat(j,0,j,j-1) = coef.submat(0,0,j-1,0).t();
                Theta.submat(j+1,j,p-1,j) = coef.submat(j,0,p-2,0);
                Theta.submat(j,j+1,j,p-1) = coef.submat(j,0,p-2,0).t();
            }

        }
    }
    
    return;
    
}

// function for glasso core computation

void glasso_core(arma::mat &W, arma::mat &Theta, arma::mat S, double lambda, double tol, int iter_max){
    int p = W.n_cols;
    //arma::mat I = arma::eye<arma::mat>(p,p);
    //W = S+lambda*I;
    arma::mat W_old = W;
    double err = 100.0;
    for (int iter=0; iter< 10*iter_max; iter++) {
        //Rcout << "glasso iteration " << iter+1 << std::endl;
        for (int j=0; j<p; j++) {
            //Rcout << "glasso variable " << j+1 << std::endl;
            glasso_inner_j(W, Theta, S, j,lambda,tol,iter_max, false);
            
        }
        err = arma::norm(W - W_old,"fro")/(arma::norm(W_old,"fro")+SMOOTH);
        W_old = W;
        if (err < tol) {
            Rcout << "glasso stops after "<< iter+1 << " iterations" << std::endl;
            break;
        }
    }
    for (int j=0; j<p; j++) {
        //Rcout << "glasso variable " << j+1 << std::endl;
        glasso_inner_j(W, Theta, S, j,lambda,tol,iter_max, true);
        
    }
    // Sanity check for Theta, in case of pathological estimate in dense situations
    arma::mat II = W*Theta;
    if (std::abs(arma::norm(II,"fro")-std::sqrt(p))>1.0) {
        Theta = arma::inv(W);
        Rcout << "Cautious about the glasso step: The algorithm does not give valid Theta estimation; a naive inversion of covariance matrix is applied!" << std::endl;
    }
    return;
}


// function for glasso with supplied initial value of W, Theta. The input is from data matrix X as well as the mean vectors for rows of X, denoted by M.
void glasso_update(arma::mat X, arma::mat M, arma::mat &W, arma::mat &Theta, double lambda, double tol, int iter_max){
    int p = X.n_cols;
    int n = X.n_rows;
    
    arma::mat X_centered = X - M;
    arma::mat S = X_centered.t()*X_centered/n;
    arma::mat I = arma::eye<arma::mat>(p,p);
    W = S+lambda*I;
    //W = sd_inv_diag*W*sd_inv_diag;
    
    //Rcout << "Begin glasso update step, check sample covariance matrix" << std::endl;
    //arma::vec eigval;
    //arma::eig_sym(eigval, S);
    //Rcout << eigval << std::endl;
    glasso_core(W, Theta, S, lambda,tol,iter_max);
    return;
}

void adaptive_glasso_update(arma::mat X, arma::mat M, arma::mat &W, arma::mat &Theta, double lambda, double tol, int iter_max){
    int p = X.n_cols;
    int n = X.n_rows;
    
    arma::mat X_centered = X - M;
    arma::mat S = X_centered.t()*X_centered/n;
    arma::vec var_vec = S.diag();
    arma::vec sd_vec = arma::sqrt(var_vec);
    arma::mat sd_diag = diagmat( sd_vec );
    arma::mat sd_inv_diag = diagmat( 1.0/sd_vec );
    S = sd_inv_diag*S*sd_inv_diag;
    arma::mat I = arma::eye<arma::mat>(p,p);
    W = S+lambda*I;
    //W = sd_inv_diag*W*sd_inv_diag;
    
    Theta = sd_diag*Theta*sd_diag;
        //Rcout << "Begin glasso update step, check sample covariance matrix" << std::endl;
        //arma::vec eigval;
        //arma::eig_sym(eigval, S);
    //Rcout << eigval << std::endl;
    glasso_core(W, Theta, S, lambda,tol,iter_max);
    W = sd_diag*W*sd_diag;
    Theta = sd_inv_diag*Theta*sd_inv_diag;
    return;
}


// function for cohesion step of the net_glasso algorithm
/*
void cohesion_update(arma::mat X, arma::mat &M, arma::mat Theta, double alpha, arma::sp_mat L){
    int p = X.n_cols;
    int n = X.n_rows;
    //int n = X.n_rows;
    

    for (int i=0; i<p; i++) {
        arma::mat Gamma = X - M;
        arma::mat yi = X.col(i);
        for (int j=0; j<p; j++) {
            if (j!=i) {
                yi = yi - (Theta(i,j)/Theta(i,i))*Gamma.col(j);
            }
        }
        arma::sp_mat I_sp = arma::speye<arma::sp_mat>(n,n);
        arma::mat mui = RNC_LS_noX(L, yi, alpha/Theta(i,i), I_sp );
        M.col(i) = mui;
    }
    
    return;
}
*/

// function for cohesion step of the net_glasso algorithm by eigen-decomposition
void cohesion_update_eigen(arma::mat X, arma::mat &M, arma::mat Theta, double alpha, arma::mat L_U, arma::vec L_tau){
    int p = X.n_cols;
    int n = X.n_rows;
    int K = L_U.n_rows;
    //int n = X.n_rows;
    
    
    for (int i=0; i<p; i++) {
        //Rcout << "cohesion update for variable " << i+1 << std::endl;
        arma::mat Gamma = X - M;
        arma::mat yi = X.col(i);
        for (int j=0; j<p; j++) {
            if (j!=i) {
                yi = yi + (Theta(i,j)/Theta(i,i))*Gamma.col(j);
            }
        }
        arma::mat mui = L_U.t()*yi;
        for (int ii=0; ii<K; ii++) {
            mui(ii) = mui(ii)/(Theta(i,i)+alpha*L_tau(ii));
        }
        mui = Theta(i,i)*L_U*mui;
        M.col(i) = mui;
    }
    
    return;
}


// function to fit net_glasso with given initial values of M, W, Theta.
/*
void net_glasso_core(arma::mat X, arma::mat &M, arma::mat &W, arma::mat &Theta, double lambda, double alpha, arma::sp_mat L, double tol, int iter_max, bool verbose){
    int p = X.n_cols;
    int n = X.n_rows;
    
    arma::mat W_old = W;
    double err = 100.0;
    
    for (int iter=0; iter<iter_max; iter++) {
        // glasso step
        if (verbose) {
            Rcout << "glasso step" << err << std::endl;
        }

        glasso_update(X, M, W, Theta, lambda, tol, iter_max);

        if (verbose) {
            Rcout << "cohesion step" << err << std::endl;
        }
        
        // network cohesion step
        cohesion_update(X, M, Theta, alpha, L);
        
        // check convergence
        err = arma::norm(W - W_old,2)/(arma::norm(W_old,2)+SMOOTH);
        W_old = W;
        if (err < tol) {
            break;
        }
        if (verbose) {
            Rcout << "Iteration " << iter << " results in relative difference " << err << std::endl;
        }
        
    }

    
    return;
}
*/

double GGM_likelihood(arma::mat X, arma::mat M, arma::mat Theta){
    arma::mat X_centered = X - M;
    int n = X.n_rows;
    double val;
    double sign;
    
    arma::log_det(val, sign, Theta);
    double result = val-arma::trace(X_centered*Theta*X_centered.t())/n;
    return result;
}

// function to fit net_glasso with given initial values of M, W, Theta by eigen-decomposition.
void net_glasso_core_eigen(arma::mat X, arma::mat &M, arma::mat &W, arma::mat &Theta, double lambda, double alpha, arma::mat L_U, arma::vec L_tau, double tol, int iter_max, bool verbose){
    int p = X.n_cols;
    int n = X.n_rows;
    
    arma::mat W_old = W;
    double err = 100.0;
    
    for (int iter=0; iter<iter_max; iter++) {
        // glasso step
        if (verbose) {
            Rcout << "glasso step" << std::endl;
            
        }
        
        glasso_update(X, M, W, Theta, lambda, tol, iter_max);
        
        if (verbose) {
            if(iter > 0){
                double llh = GGM_likelihood(X,M,Theta);
                double obj = llh - lambda*arma::sum(arma::sum(arma::abs(Theta))) - alpha*arma::trace(M.t()*L_U*arma::diagmat(L_tau)*L_U*M)/n;
                Rcout << "likelihood after glasso step: "<< llh << std::endl;
                Rcout << "objective after glasso step: "<< obj << std::endl;
            }
            Rcout << "cohesion step" << std::endl;
        }
        
        // network cohesion step
        cohesion_update_eigen(X, M, Theta, alpha, L_U, L_tau);
        if (verbose) {
            if(iter > 0){
                double llh = GGM_likelihood(X,M,Theta);
                double obj = llh - lambda*arma::sum(arma::sum(arma::abs(Theta))) - alpha*arma::trace(M.t()*L_U*arma::diagmat(L_tau)*L_U*M)/n;
                Rcout << "likelihood after cohesion step: "<< llh << std::endl;
                Rcout << "objective after cohesion step: "<< obj << std::endl;
            }

        }
        
        // check convergence
        err = arma::norm(W - W_old,"fro")/(arma::norm(W_old,"fro")+SMOOTH);
        W_old = W;
        if (err < tol) {
            break;
        }
        if (verbose) {
            Rcout << "Iteration " << iter << " results in relative difference " << err << std::endl;
        }
        
    }
    
    Rcout << "Estimation done!" << std::endl;
    
    return;
}





// function for cohesion step of the net_glasso algorithm with different variances
/*
void cohesion_update_heterogenous(arma::mat X, arma::mat &M, arma::mat &W, arma::mat Theta, double alpha, arma::sp_mat L){
    int p = X.n_cols;
    int n = X.n_rows;
    //int n = X.n_rows;
    
    
    for (int i=0; i<p; i++) {
        arma::mat Gamma = X - M;
        arma::mat yi = X.col(i);
        for (int j=0; j<p; j++) {
            if (j!=i) {
                yi = yi - (Theta(i,j)/Theta(i,i))*Gamma.col(j);
            }
        }
        arma::sp_mat I_sp = arma::speye<arma::sp_mat>(n,n);
        arma::mat mui = RNC_LS_noX(L, yi, alpha/(Theta(i,i)*W(i,i)), I_sp );
        M.col(i) = mui;
    }
    
    return;
}
*/




// function for cohesion step of the net_glasso algorithm with different variances by eigen-decomposition
void cohesion_update_heterogenous_eigen(arma::mat X, arma::mat &M, arma::mat &W, arma::mat Theta, double alpha, arma::mat L_U, arma::vec L_tau){
    int p = X.n_cols;
    int n = X.n_rows;
    //int n = X.n_rows;
    
    
    for (int i=0; i<p; i++) {
        arma::mat Gamma = X - M;
        
        arma::mat yi = X.col(i);
        //Rcout << "cohesion update for variable " << i+1 << std::endl;
        for (int j=0; j<p; j++) {
            if (j!=i) {
                yi = yi + (Theta(i,j)/Theta(i,i))*Gamma.col(j);
            }
        }
        arma::mat mui = L_U.t()*yi;

        for (int ii=0; ii<n; ii++) {
            mui(ii,0) = mui(ii,0)/(Theta(i,i)*W(i,i)+alpha*L_tau(ii));
        }
        
        mui = Theta(i,i)*W(i,i)*L_U*mui;
        M.col(i) = mui;
    }
    
    return;
}

//void cohesion_update_heterogenous_eigen(arma::mat X, arma::mat &M, arma::mat &W, arma::mat Theta, double alpha, arma::mat L_U, arma::vec L_tau){
//    int p = X.n_cols;
//    int n = X.n_rows;
//    //int n = X.n_rows;
//    arma::mat  One = arma::ones<arma::mat>(n,1);
//    arma::mat Centers = One*One.t()*M/n;
//    arma::mat M_centered = M - Centers;
//    arma::mat M_Cov = M_centered.t()*M_centered/n;
//    
//    arma::vec scale_vec = M_Cov.diag();
//    
//    
//    for (int i=0; i<p; i++) {
//        arma::mat Gamma = X - M;
//        
//        arma::mat yi = X.col(i);
//        //Rcout << "cohesion update for variable " << i+1 << std::endl;
//        for (int j=0; j<p; j++) {
//            if (j!=i) {
//                yi = yi + (Theta(i,j)/Theta(i,i))*Gamma.col(j);
//            }
//        }
//        arma::mat mui = L_U.t()*yi;
//        
//        for (int ii=0; ii<n; ii++) {
//            mui(ii,0) = mui(ii,0)/(Theta(i,i)*scale_vec(i)+alpha*L_tau(ii));
//        }
//        
//        mui = Theta(i,i)*scale_vec(i)*L_U*mui;
//        M.col(i) = mui;
//    }
//    
//    return;
//}



// function to fit net_glasso with given initial values of M, W, Theta with unequal variances.
/*
void net_glasso_core_heterogenous(arma::mat X, arma::mat &M, arma::mat &W, arma::mat &Theta, double lambda, double alpha, arma::sp_mat L, double tol, int iter_max, bool verbose){
    int p = X.n_cols;
    int n = X.n_rows;
    
    arma::mat W_old = W;
    double err = 100.0;
    
    for (int iter=0; iter<iter_max; iter++) {
        // glasso step
        if (verbose) {
            Rcout << "glasso step" << err << std::endl;
        }
        
        glasso_update(X, M, W, Theta, lambda, tol, iter_max);
        
        if (verbose) {
            Rcout << "cohesion step" << err << std::endl;
        }
        
        // network cohesion step
        cohesion_update_heterogenous(X, M, W, Theta, alpha, L);
        
        // check convergence
        err = arma::norm(W - W_old,2)/(arma::norm(W_old,2)+SMOOTH);
        W_old = W;
        if (err < tol) {
            break;
        }
        if (verbose) {
            Rcout << "Iteration " << iter << " results in relative difference " << err << std::endl;
        }
        
    }
    
    
    return;
}
*/



// function to fit net_glasso with given initial values of M, W, Theta with unequal variances by eigen-decomposition.
void net_glasso_core_heterogenous_eigen(arma::mat X, arma::mat &M, arma::mat &W, arma::mat &Theta, double lambda, double alpha, arma::mat L_U, arma::vec L_tau, double tol, int iter_max, bool verbose){
    int p = X.n_cols;
    int n = X.n_rows;
    
    arma::mat W_old = W;
    double err = 100.0;
    
    for (int iter=0; iter<iter_max; iter++) {
        // glasso step
        if (verbose) {
            Rcout << "glasso step" << std::endl;
        }
        
        adaptive_glasso_update(X, M, W, Theta, lambda, tol, iter_max);
        //arma::mat M_old = M;
        if (verbose) {
            double llh = GGM_likelihood(X,M,Theta);
            Rcout << "likelihood after glasso step: "<< llh << std::endl;
            Rcout << "heterogenous cohesion step" << std::endl;
        }
        // network cohesion step
        
        cohesion_update_heterogenous_eigen(X, M, W, Theta, alpha, L_U, L_tau);
        if (verbose) {
            double llh = GGM_likelihood(X,M,Theta);
            Rcout << "likelihood after cohesion step: "<< llh << std::endl;
        }
        err = arma::norm(W - W_old,"fro")/(arma::norm(W_old,"fro")+SMOOTH);
        W_old = W;
        if (verbose) {
            Rcout << "Iteration " << iter << " results in relative difference " << err << std::endl;
            //Rcout << M.col(98) << std::endl;
        }
        if (err < tol) {
            break;
        }
        
    }
    
    Rcout << "Estimation done!" << std::endl;
    return;
}




// [[Rcpp::export]]
extern "C" SEXP glasso_null(SEXP X, SEXP lambda){
    //Rcout << "Begin converting objects " << std::endl;
    double lambda_num= as<double>(lambda);


    arma::mat Xmat=as<arma::mat>(X);
    int p = Xmat.n_cols;
    int n = Xmat.n_rows;
    arma::mat Smat = Xmat.t()*Xmat/n;

    
    arma::mat I = arma::eye<arma::mat>(p,p);
    arma::mat Wmat = Smat+lambda_num*I;
    arma::mat Thetamat = Wmat;
    //W = sd_inv_diag*W*sd_inv_diag;
    
    
    double tol = 0.0001;
    int max_iter = 1000;
    glasso_core(Wmat, Thetamat, Smat, lambda_num,tol,max_iter);

    return List::create(Named("W") = Wmat,
                        Named("Theta")       = Thetamat);
}



// [[Rcpp::export]]
extern "C" SEXP net_glasso(SEXP X, SEXP LU, SEXP Ltau, SEXP lambda, SEXP alpha, SEXP tol, SEXP iter_max, SEXP verbose, SEXP W_init, SEXP Theta_init, SEXP M_init,SEXP hetero){
    //Rcout << "Begin converting objects " << std::endl;
    double lambda_num= as<double>(lambda);
    double alpha_num= as<double>(alpha);
    double tol_num= as<double>(tol);
    int iter_max_num= as<double>(iter_max);
    bool verbose_ind= as<bool>(verbose);
    bool hetero_ind= as<bool>(hetero);
    //arma::sp_mat Lspmat=arma::sp_mat(Ldsmat);
    arma::mat Xmat=as<arma::mat>(X);
    arma::mat L_U=as<arma::mat>(LU);
    arma::vec L_tau=as<arma::vec>(Ltau);
    arma::mat Wmat=as<arma::mat>(W_init);
    arma::mat Thetamat=as<arma::mat>(Theta_init);
    arma::mat Mmat=as<arma::mat>(M_init);
    
    // note that here we assume X is already centered. The centering step should be done in R.
    int n = Xmat.n_rows;
    //arma::mat S = Xmat.t()*Xmat/n;
    int p = Xmat.n_cols;
    //arma::mat I = arma::eye<arma::mat>(p,p);
    //arma::mat Wmat = S+lambda_num*I;
    //arma::mat Thetamat = Wmat; // the default initialization of Theta is relatively arbitrary since it will not be used in glasso iterations. (We first do glasso then do cohesion.)
    //arma::mat Mmat = arma::zeros<arma::mat>(n,p);
    if (hetero_ind) {
        net_glasso_core_heterogenous_eigen(Xmat, Mmat, Wmat, Thetamat, lambda_num, alpha_num, L_U, L_tau, tol_num, iter_max_num,verbose_ind);
    }else{
        net_glasso_core_eigen(Xmat, Mmat, Wmat, Thetamat, lambda_num, alpha_num, L_U, L_tau, tol_num, iter_max_num,verbose_ind);
    }
    return List::create(Named("W") = Wmat,
                        Named("Theta") = Thetamat,
                        Named("M") = Mmat,
                        Named("lambda") = lambda_num,
                        Named("alpha") = alpha_num
                        );
}





